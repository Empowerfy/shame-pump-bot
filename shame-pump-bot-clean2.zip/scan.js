// scan.js — polls Helius for Pump.fun coins and adds them to Google Sheets
import fs from 'fs';

// Node 18+ has global fetch
const fetch = globalThis.fetch;

const HELIUS_KEY = process.env.HELIUS_KEY;
const API = process.env.APPS_SCRIPT_API;

console.log('[scan] start');
console.log('[scan] node', process.version);
console.log('[scan] HELIUS_KEY set?', Boolean(HELIUS_KEY));
console.log('[scan] APPS_SCRIPT_API ok?', API?.startsWith('https://script.google.com/macros/'));

if (!HELIUS_KEY || !API) {
  console.error('[scan] Missing HELIUS_KEY or APPS_SCRIPT_API');
  process.exit(1);
}

// Verified Pump.fun BondingCurve program ID (Solana)
const PUMP_PROGRAM_IDS = [
  'Pump111111111111111111111111111111111111111'
];

const STATE_FILE = 'last-pump.json';

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return { seen: {} };
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return { seen: {} };
  }
}
function saveState(s) {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2)); } catch {}
}

async function fetchRecent() {
  const out = [];
  for (const pid of PUMP_PROGRAM_IDS) {
    const url = `https://api.helius.xyz/v0/addresses/${pid}/transactions?api-key=${HELIUS_KEY}&limit=20`;
    console.log('[scan] GET', url.replace(HELIUS_KEY, '***'));
    try {
      const res = await fetch(url);
      if (!res.ok) { console.error('[scan] Helius status', res.status); continue; }
      const txs = await res.json();
      console.log('[scan] tx count', Array.isArray(txs) ? txs.length : 0);
      for (const tx of txs) {
        const logs = tx?.meta?.logMessages?.join(' ') || '';
        if (/bond|complete|enabled/i.test(logs)) {
          const mint = tx?.tokenTransfers?.[0]?.mint || tx?.events?.token?.mint || null;
          if (mint) out.push({ mint });
        }
      }
    } catch (e) {
      console.error('[scan] fetch error', e.message);
    }
  }
  return out;
}

async function addCoin(c) {
  const body = { addCoin: { mint: c.mint, name: `Pump ${c.mint.slice(0,4)}`, symbol: '' } };
  console.log('[scan] addCoin', body);
  try {
    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const text = await res.text();
    if (!res.ok) {
      console.error('[scan] addCoin status', res.status, text);
    } else {
      console.log('[scan] addCoin ok', text);
    }
  } catch (e) {
    console.error('[scan] addCoin error', e.message);
  }
}

async function main() {
  const state = loadState();
  const recent = await fetchRecent();
  console.log('[scan] candidates', recent.length);
  let added = 0;
  for (const c of recent) {
    if (state.seen[c.mint]) continue;
    await addCoin(c);
    state.seen[c.mint] = Date.now();
    added++;
    if (added >= 20) break;
  }
  saveState(state);
  console.log('[scan] done. added', added);
}

main().catch(e => { console.error('[scan] fatal', e); process.exit(1); });
